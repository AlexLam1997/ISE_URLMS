package ca.mcgill.ecse321.urlms;

import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import ca.mcgill.ecse321.labmanagementsystem.model.*;
import ca.mcgill.ecse321.labmanagementsystem.controller.*;

public class AddStaff extends AppCompatActivity {
    private URLMS urlms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_staff);

        //Actions when the button is clicked
        Button button = (Button) findViewById(R.id.addStaff_button);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                EditText name = (EditText) findViewById(R.id.name);
                EditText idNumber = (EditText) findViewById(R.id.idNumber);
                EditText role = (EditText) findViewById(R.id.role);

                URLMSController uc = new URLMSController(urlms);
                try {
                    uc.createStaff(name.getText().toString(), idNumber.getText().toString(), role.getText().toString());

                    //Display success
                    Snackbar.make(v, "Successfully Added!", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();

                    // Refresh text fields
                    name.setText("");
                    idNumber.setText("");
                    role.setText("");

                } catch (InvalidInputException e) {
                    //Display input error
                    Snackbar.make(v, "Input cannot be empty!", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                }
            }
        });
    }

}
